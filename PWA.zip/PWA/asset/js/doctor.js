/* ==================================================
   DOCTOR.JS — For Doctor Dashboard Interactions
   ================================================== */

// ✅ View Chart button
document.querySelectorAll(".view-chart").forEach((btn) => {
  btn.addEventListener("click", () => {
    const patientId = btn.dataset.id;
    window.location.href = `views/doctor_view_chart.php?patient_id=${patientId}`;
  });
});

// ✅ Appointment Requests - Auto Refresh
function loadAppointmentRequests() {
  fetch("php/doctor_appointments.php")
    .then((res) => res.text())
    .then((html) => {
      document.getElementById("appointmentRequests").innerHTML = html;
    });
}
if (document.getElementById("appointmentRequests")) {
  setInterval(loadAppointmentRequests, 4000);
}

// ✅ Approve / Reject Appointment
document.querySelectorAll(".btn-approve, .btn-reject").forEach((btn) => {
  btn.addEventListener("click", () => {
    const action = btn.classList.contains("btn-approve") ? "approve" : "reject";
    const id = btn.dataset.id;

    fetch("php/doctor_update_appointment.php", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: `id=${id}&action=${action}`,
    })
      .then((res) => res.text())
      .then((response) => {
        showToast(response, "success");
        loadAppointmentRequests();
      })
      .catch((err) => console.error(err));
  });
});

// ✅ Search Appointments (Doctor 4)
const doctorSearch = document.getElementById("doctorSearch");
if (doctorSearch) {
  doctorSearch.addEventListener("input", () => {
    const term = doctorSearch.value.toLowerCase();
    document.querySelectorAll("#doctorTable tbody tr").forEach((row) => {
      row.style.display = row.textContent.toLowerCase().includes(term) ? "" : "none";
    });
  });
}
