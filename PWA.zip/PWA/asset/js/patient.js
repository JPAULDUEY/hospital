/* ==================================================
   PATIENT.JS — For Patient Dashboard Interactions
   ================================================== */

// ✅ Appointment Form Submit
const bookForm = document.getElementById("appointmentForm");
if (bookForm) {
  bookForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const formData = new FormData(bookForm);

    fetch("php/patient_book_appointment.php", {
      method: "POST",
      body: formData,
    })
      .then((res) => res.text())
      .then((response) => {
        showToast(response, "success");
        bookForm.reset();
      })
      .catch((err) => console.error(err));
  });
}

// ✅ Appointment History Search
const patientSearch = document.getElementById("patientSearch");
if (patientSearch) {
  patientSearch.addEventListener("input", () => {
    const term = patientSearch.value.toLowerCase();
    document.querySelectorAll("#appointmentTable tbody tr").forEach((row) => {
      row.style.display = row.textContent.toLowerCase().includes(term) ? "" : "none";
    });
  });
}

// ✅ Download Medical History as PDF
document.querySelectorAll(".btn-download").forEach((btn) => {
  btn.addEventListener("click", () => {
    const historyId = btn.dataset.id;
    window.location.href = `php/patient_download_pdf.php?id=${historyId}`;
  });
});
