/* ==========================================
   MAIN.JS — Global JavaScript for System
   ========================================== */

/**
 * Sidebar Toggle (for small screens)
 * Used in admin, doctor, and patient dashboards
 */
document.addEventListener("DOMContentLoaded", function () {
  const toggleBtn = document.querySelector("#menu-toggle");
  const sidebar = document.querySelector(".sidebar");

  if (toggleBtn && sidebar) {
    toggleBtn.addEventListener("click", () => {
      sidebar.classList.toggle("hidden");
    });
  }
});

/**
 * Fade In Animation on Page Load
 * Applies to all pages for smooth UX
 */
window.addEventListener("load", () => {
  const fadeElements = document.querySelectorAll(".fade-in");
  fadeElements.forEach((el) => {
    el.style.opacity = 0;
    el.style.transition = "opacity 0.6s ease-in-out";
    setTimeout(() => (el.style.opacity = 1), 100);
  });
});

/**
 * Logout Confirmation (for all dashboards)
 */
const logoutLinks = document.querySelectorAll(".logout-link");
logoutLinks.forEach((link) => {
  link.addEventListener("click", (e) => {
    e.preventDefault();
    if (confirm("Are you sure you want to log out?")) {
      window.location.href = "logout.php";
    }
  });
});

/**
 * Alert Close Button (for success/error messages)
 */
document.querySelectorAll(".alert").forEach((alert) => {
  const closeBtn = alert.querySelector(".alert-close");
  if (closeBtn) {
    closeBtn.addEventListener("click", () => {
      alert.style.opacity = "0";
      setTimeout(() => alert.remove(), 300);
    });
  }
});

/**
 * Real-time Clock (optional)
 * Use <span id="clock"></span> in navbar to show
 */
function updateClock() {
  const clock = document.getElementById("clock");
  if (clock) {
    const now = new Date();
    const hours = now.getHours().toString().padStart(2, "0");
    const minutes = now.getMinutes().toString().padStart(2, "0");
    const seconds = now.getSeconds().toString().padStart(2, "0");
    clock.textContent = `${hours}:${minutes}:${seconds}`;
  }
}
setInterval(updateClock, 1000);
updateClock();

/**
 * Simple Toast Notification (for feedback)
 * Example: showToast("Appointment saved successfully!", "success");
 */
function showToast(message, type = "info") {
  const toast = document.createElement("div");
  toast.className = `toast ${type}`;
  toast.textContent = message;
  document.body.appendChild(toast);

  setTimeout(() => toast.classList.add("show"), 100);
  setTimeout(() => {
    toast.classList.remove("show");
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}

// Style for toast notification (optional)
const style = document.createElement("style");
style.textContent = `
.toast {
  position: fixed;
  bottom: 30px;
  right: 30px;
  background: #1e3a8a;
  color: white;
  padding: 10px 20px;
  border-radius: 8px;
  opacity: 0;
  transform: translateY(20px);
  transition: all 0.3s ease;
  z-index: 9999;
}
.toast.show {
  opacity: 1;
  transform: translateY(0);
}
.toast.success { background: #16a34a; }
.toast.error { background: #dc2626; }
.toast.info { background: #2563eb; }
`;
document.head.appendChild(style);
