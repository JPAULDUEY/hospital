<?php
<?php
include __DIR__ . '/php/config/db_connect.php';
echo ($conn && !$conn->connect_error) ? "DB connected: hospital_system" : "DB connection failed";
?>