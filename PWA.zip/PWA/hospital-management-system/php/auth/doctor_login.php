Sure, here's the content for the file: /hospital-management-system/hospital-management-system/php/auth/doctor_login.php

<?php
session_start();
include_once("../config/db_connect.php");

// If already logged in, redirect to dashboard
if (isset($_SESSION['doctor_id'])) {
    header("Location: ../../views/patients/dashboard.html");
    exit;
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    // Validate inputs
    if (empty($email) || empty($password)) {
        echo json_encode(["status" => "error", "message" => "All fields are required."]);
        exit;
    }

    // Query doctor table
    $stmt = $conn->prepare("SELECT * FROM doctors WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if doctor exists
    if ($result->num_rows > 0) {
        $doctor = $result->fetch_assoc();

        // Verify password (plain text or hashed)
        if (password_verify($password, $doctor['password']) || $password === $doctor['password']) {

            // Store session data
            $_SESSION['doctor_id'] = $doctor['id'];
            $_SESSION['doctor_name'] = $doctor['name'];
            $_SESSION['role'] = 'doctor';

            echo json_encode(["status" => "success", "message" => "Login successful"]);
        } else {
            echo json_encode(["status" => "error", "message" => "Invalid password."]);
        }
    } else {
        echo json_encode(["status" => "error", "message" => "Doctor not found."]);
    }

    $stmt->close();
    $conn->close();
} else {
    echo json_encode(["status" => "error", "message" => "Invalid request method."]);
}
?>