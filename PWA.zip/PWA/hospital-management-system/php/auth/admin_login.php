hospital-management-system
├── config
│   └── db_connect.php
├── php
│   ├── auth
│   │   ├── admin_login.php
│   │   ├── doctor_login.php
│   │   └── patient_login.php
│   └── controllers
│       ├── admin_controller.php
│       ├── appointment_controller.php
│       └── patient_controller.php
├── views
│   ├── admin
│   │   ├── dashboard.html
│   │   └── patients.html
│   └── patients
│       └── dashboard.html
├── assets
│   ├── css
│   │   └── styles.css
│   └── js
│       └── main.js
├── database
│   └── schema.sql
├── index.html
└── README.md