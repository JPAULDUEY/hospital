<?php
include_once("../config/db_connect.php");

// Function to get all admins
function getAllAdmins() {
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM admin");
    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

// Function to get a specific admin by ID
function getAdminById($id) {
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM admin WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    return $stmt->get_result()->fetch_assoc();
}

// Function to create a new admin
function createAdmin($email, $password, $name) {
    global $conn;
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $conn->prepare("INSERT INTO admin (email, password, name) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $email, $hashedPassword, $name);
    return $stmt->execute();
}

// Function to update an existing admin
function updateAdmin($id, $email, $name) {
    global $conn;
    $stmt = $conn->prepare("UPDATE admin SET email = ?, name = ? WHERE id = ?");
    $stmt->bind_param("ssi", $email, $name, $id);
    return $stmt->execute();
}

// Function to delete an admin
function deleteAdmin($id) {
    global $conn;
    $stmt = $conn->prepare("DELETE FROM admin WHERE id = ?");
    $stmt->bind_param("i", $id);
    return $stmt->execute();
}
?>