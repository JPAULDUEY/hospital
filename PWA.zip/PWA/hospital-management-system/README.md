# Hospital Management System

## Overview
The Hospital Management System is a web application designed to manage various aspects of hospital operations, including user authentication for admins, doctors, and patients, as well as appointment management and patient record handling.

## Features
- Admin, doctor, and patient login functionality.
- Admin dashboard for managing users and appointments.
- Patient dashboard for accessing personal information and appointments.
- Responsive design with a user-friendly interface.

## Project Structure
```
hospital-management-system
├── config
│   └── db_connect.php
├── php
│   ├── auth
│   │   ├── admin_login.php
│   │   ├── doctor_login.php
│   │   └── patient_login.php
│   └── controllers
│       ├── admin_controller.php
│       ├── appointment_controller.php
│       └── patient_controller.php
├── views
│   ├── admin
│   │   ├── dashboard.html
│   │   └── patients.html
│   └── patients
│       └── dashboard.html
├── assets
│   ├── css
│   │   └── styles.css
│   └── js
│       └── main.js
├── database
│   └── schema.sql
├── index.html
└── README.md
```

## Setup Instructions
1. Clone the repository to your local machine.
2. Navigate to the project directory.
3. Set up the database using the `database/schema.sql` file.
4. Configure the database connection in `config/db_connect.php` with your database credentials.
5. Open `index.html` in your web browser to access the application.

## Usage
- Access the admin login page at `php/auth/admin_login.php`.
- Access the doctor login page at `php/auth/doctor_login.php`.
- Access the patient login page at `php/auth/patient_login.php`.
- Use the admin dashboard to manage appointments and users.
- Patients can view their dashboard to manage their appointments and personal information.

## Contributing
Contributions are welcome! Please submit a pull request or open an issue for any enhancements or bug fixes.