<?php
<?php
header('Content-Type: application/json; charset=utf-8');
include_once __DIR__ . '/../config/db_connect.php';

// Map possible current_status values to dashboard keys. Update variants to match your data.
$statuses = [
  'waiting_room' => ['waiting','waiting_room','in_queue'],
  'in_exam' => ['exam','in_exam','consultation'],
  'lab_xray' => ['lab','xray','lab_xray'],
  'awaiting_discharge' => ['awaiting_discharge','discharge_pending'],
  'complete_visit' => ['complete','completed','discharged']
];

$out = array_fill_keys(array_keys($statuses), 0);
$out['other'] = 0;

// Adjust the FROM table/column to match your schema. This assumes patients.current_status
$sql = "SELECT current_status, COUNT(*) AS cnt FROM patients GROUP BY current_status";
$res = $conn->query($sql);
if($res){
  while($r = $res->fetch_assoc()){
    $cs = strtolower($r['current_status'] ?? '');
    $matched = false;
    foreach($statuses as $key => $variants){
      foreach($variants as $v){
        if(strpos($cs, $v) !== false){ $out[$key] += (int)$r['cnt']; $matched = true; break; }
      }
      if($matched) break;
    }
    if(!$matched) $out['other'] += (int)$r['cnt'];
  }
}

echo json_encode($out);
$conn->close();