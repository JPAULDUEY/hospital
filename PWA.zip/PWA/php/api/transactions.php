<?php
<?php
header('Content-Type: application/json; charset=utf-8');
include_once __DIR__ . '/../config/db_connect.php';

// Assumes a `transactions` table with `created_at` DATETIME and `actor_type` ('patient' or 'doctor').
// If your schema differs, update the SQL to match.
$days = 7;
$labels = [];
for($i=$days-1;$i>=0;$i--){
  $labels[] = date('D', strtotime("-{$i} days"));
}

$patients = array_fill(0,$days,0);
$doctors  = array_fill(0,$days,0);

$sql = "SELECT DATE(created_at) as dt, actor_type, COUNT(*) as cnt
        FROM transactions
        WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL ".($days-1)." DAY)
        GROUP BY DATE(created_at), actor_type";
$res = $conn->query($sql);
$map = [];
if($res){
  while($r = $res->fetch_assoc()){
    $map[$r['dt']][strtolower($r['actor_type'])] = (int)$r['cnt'];
  }
}

for($i=0;$i<$days;$i++){
  $d = date('Y-m-d', strtotime("-".($days-1-$i)." days"));
  $patients[$i] = $map[$d]['patient'] ?? 0;
  $doctors[$i]  = $map[$d]['doctor'] ?? 0;
}

echo json_encode(['labels'=>$labels,'patients'=>$patients,'doctors'=>$doctors]);
$conn->close();