<?php
<?php
// optional: session check
// session_start();
// if (!isset($_SESSION['admin_id'])) { header('Location: /PWA/php/login_page/admin_login.php'); exit; }
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>ADMIN | DASHBOARD</title>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    /* minor visual tweaks to match supplied design */
    .card { background: #ffffffcc; border-radius:12px; box-shadow:0 6px 18px rgba(0,0,0,0.12); }
    .flow-box { border-radius:8px; color:#fff; font-weight:700; display:flex; flex-direction:column; justify-content:center; align-items:center; padding:18px; min-height:90px; }
  </style>
</head>
<body class="min-h-screen bg-gradient-to-r from-teal-200 to-cyan-300 p-6">
  <div class="max-w-7xl mx-auto">
    <header class="mb-6 flex items-center justify-between">
      <div>
        <h1 class="text-3xl font-extrabold tracking-tight">ADMIN | DASHBOARD</h1>
        <div class="text-sm text-slate-700">ADMIN / DASHBOARD</div>
      </div>
      <div class="flex items-center gap-4">
        <div class="text-sm">Admin</div>
        <div class="w-10 h-10 rounded-full bg-white/80 flex items-center justify-center">👤</div>
      </div>
    </header>

    <div class="grid grid-cols-12 gap-6">
      <!-- Left nav -->
      <aside class="col-span-3">
        <div class="card p-4 h-full">
          <div class="bg-teal-300 p-3 rounded mb-4 font-semibold">ADMIN NAVIGATION</div>
          <ul class="space-y-2 text-sm">
            <li class="px-3 py-2 bg-white/50 rounded">Dashboard</li>
            <li class="px-3 py-2 bg-white/50 rounded">User Session Log</li>
            <li class="px-3 py-2 bg-white/50 rounded">Doctors</li>
            <li class="px-3 py-2 bg-white/50 rounded">Users</li>
            <li class="px-3 py-2 bg-white/50 rounded">Patients</li>
            <li class="px-3 py-2 bg-white/50 rounded">Appointment History</li>
            <li class="px-3 py-2 bg-white/50 rounded">Doctor Session Log</li>
            <li class="px-3 py-2 bg-white/50 rounded">Patient Search</li>
          </ul>
        </div>
      </aside>

      <!-- Main -->
      <main class="col-span-9 space-y-6">
        <div class="grid grid-cols-2 gap-6">
          <!-- Wave chart card -->
          <section class="card p-6">
            <h2 class="text-lg font-semibold mb-3">DAILY PATIENT AND DOCTOR TRANSACTION</h2>
            <canvas id="waveChart" height="220"></canvas>
          </section>

          <!-- Patient flow -->
          <section class="card p-6">
            <h2 class="text-lg font-semibold mb-3">PATIENT FLOW OVERVIEW</h2>
            <div id="flowGrid" class="grid grid-cols-2 gap-4">
              <div class="flow-box" data-key="waiting_room" style="background:#f7ec3b;color:#111">WAITING ROOM <span class="text-2xl mt-2 flow-count">0</span></div>
              <div class="flow-box" data-key="in_exam" style="background:#4f9cff">IN EXAM ROOM <span class="text-2xl mt-2 flow-count">0</span></div>
              <div class="flow-box" data-key="lab_xray" style="background:#9b59b6">LAB / X-RAY <span class="text-2xl mt-2 flow-count">0</span></div>
              <div class="flow-box" data-key="awaiting_discharge" style="background:#ff6b35">AWAITING DISCHARGE <span class="text-2xl mt-2 flow-count">0</span></div>
              <div class="flow-box" data-key="complete_visit" style="background:#28a745">COMPLETE VISIT <span class="text-2xl mt-2 flow-count">0</span></div>
              <div class="flow-box" data-key="other" style="background:#d1d5db;color:#111">OTHER <span class="text-2xl mt-2 flow-count">0</span></div>
            </div>
          </section>
        </div>

        <!-- Real-time patient status -->
        <section class="card p-6">
          <h2 class="text-lg font-semibold mb-3">REAL-TIME PATIENT STATUS</h2>
          <div class="overflow-auto">
            <table class="min-w-full text-sm">
              <thead class="bg-slate-100">
                <tr>
                  <th class="px-4 py-3 text-left">Patient Name</th>
                  <th class="px-4 py-3 text-left">Doctor</th>
                  <th class="px-4 py-3 text-left">Current Status</th>
                  <th class="px-4 py-3 text-left">Status Duration</th>
                  <th class="px-4 py-3 text-left">Updated At</th>
                </tr>
              </thead>
              <tbody id="realtimeBody"></tbody>
            </table>
          </div>
        </section>
      </main>
    </div>
  </div>

<script>
const apiBase = '/PWA/php/api';

// Chart.js setup
const ctx = document.getElementById('waveChart').getContext('2d');
const waveChart = new Chart(ctx, {
  type: 'line',
  data: { labels: [], datasets: [
    { label: 'Patients', data: [], borderColor:'#095c4b', backgroundColor:'rgba(9,92,75,0.12)', fill:true, tension:0.35 },
    { label: 'Doctors',  data: [], borderColor:'#1d4ed8', backgroundColor:'rgba(29,78,216,0.08)', fill:true, tension:0.35 }
  ]},
  options: { responsive:true, plugins:{legend:{position:'top'}}, scales:{y:{beginAtZero:true}}}
});

function fmtDuration(seconds){
  if(seconds < 60) return seconds + 's';
  if(seconds < 3600) return Math.floor(seconds/60)+'m '+(seconds%60)+'s';
  return Math.floor(seconds/3600)+'h '+Math.floor((seconds%3600)/60)+'m';
}

async function loadTransactions(){
  try{
    const res = await fetch(apiBase + '/transactions.php');
    if(!res.ok) throw new Error('transactions fetch failed');
    const json = await res.json();
    waveChart.data.labels = json.labels;
    waveChart.data.datasets[0].data = json.patients;
    waveChart.data.datasets[1].data = json.doctors;
    waveChart.update();
  }catch(e){ console.error(e); }
}

async function loadFlow(){
  try{
    const res = await fetch(apiBase + '/patient_flow.php');
    if(!res.ok) throw new Error('flow fetch failed');
    const json = await res.json();
    document.querySelectorAll('#flowGrid [data-key]').forEach(el=>{
      const key = el.getAttribute('data-key');
      el.querySelector('.flow-count').textContent = (json[key] ?? 0);
    });
  }catch(e){ console.error(e); }
}

async function loadRealtime(){
  try{
    const res = await fetch(apiBase + '/realtime_patients.php');
    if(!res.ok) throw new Error('realtime fetch failed');
    const list = await res.json();
    const tbody = document.getElementById('realtimeBody');
    tbody.innerHTML = '';
    const now = Date.now();
    list.forEach(p=>{
      const updated = new Date(p.status_updated_at).getTime();
      const seconds = Math.max(0, Math.floor((now - updated)/1000));
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td class="px-4 py-3 border-t">${p.name || ''}</td>
        <td class="px-4 py-3 border-t">${p.doctor || ''}</td>
        <td class="px-4 py-3 border-t">${p.current_status || ''}</td>
        <td class="px-4 py-3 border-t">${fmtDuration(seconds)}</td>
        <td class="px-4 py-3 border-t">${new Date(p.status_updated_at).toLocaleString()}</td>
      `;
      tbody.appendChild(tr);
    });
  }catch(e){ console.error(e); }
}

// initial load + polling
loadTransactions(); loadFlow(); loadRealtime();
setInterval(loadTransactions, 30000);
setInterval(loadFlow, 10000);
setInterval(loadRealtime, 5000);
</script>
</body>
</html>