<?php
<?php
header('Content-Type: application/json; charset=utf-8');
include_once __DIR__ . '/../config/db_connect.php';

// Adjust column names to match your schema. This uses patients.name, patients.doctor_assigned, patients.current_status, patients.status_updated_at
$sql = "SELECT
          COALESCE(p.name, '') AS name,
          COALESCE(d.name, '') AS doctor,
          COALESCE(p.current_status, '') AS current_status,
          COALESCE(p.status_updated_at, p.updated_at, p.created_at) AS status_updated_at
        FROM patients p
        LEFT JOIN doctors d ON d.id = p.doctor_id
        WHERE p.current_status IS NOT NULL
        ORDER BY p.status_updated_at DESC
        LIMIT 100";
$res = $conn->query($sql);
$out = [];
if($res){
  while($r = $res->fetch_assoc()){
    // ensure ISO datetime format for JS Date
    $r['status_updated_at'] = date('c', strtotime($r['status_updated_at']));
    $out[] = $r;
  }
}

echo json_encode($out);
$conn->close();