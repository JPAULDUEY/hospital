<?php
<?php
// create_admin_account.php
// Run once: http://localhost/PWA/php/scripts/create_admin_account.php

include_once __DIR__ . '/../config/db_connect.php';

$email = 'admin@hospital.com';
$password = 'admin123';
$full_name = 'Administrator';
$contact_no = '';

function columns($conn, $table){
    $cols = [];
    $res = $conn->query("SHOW COLUMNS FROM `{$table}`");
    if($res){
        while($r = $res->fetch_assoc()) $cols[] = $r['Field'];
    }
    return $cols;
}

$table = 'admin';
$cols = columns($conn, $table);

if(!in_array('email', $cols)){
    $sql = "ALTER TABLE `{$table}` ADD COLUMN `email` VARCHAR(150) NULL AFTER `full_name`";
    $conn->query($sql);
    echo "Added column email<br>";
}
if(!in_array('password', $cols)){
    $sql = "ALTER TABLE `{$table}` ADD COLUMN `password` VARCHAR(255) NULL AFTER `email`";
    $conn->query($sql);
    echo "Added column password<br>";
}

// refresh columns
$cols = columns($conn, $table);

// decide columns to insert/update
$insertCols = [];
$insertVals = [];
if(in_array('full_name', $cols)){ $insertCols[] = 'full_name'; $insertVals[] = $full_name; }
if(in_array('email', $cols)){ $insertCols[] = 'email'; $insertVals[] = $email; }
if(in_array('password', $cols)){ $insertCols[] = 'password'; $insertVals[] = password_hash($password, PASSWORD_DEFAULT); }
if(in_array('contact_no', $cols)){ $insertCols[] = 'contact_no'; $insertVals[] = $contact_no; }
if(in_array('user_id', $cols) && !in_array('user_id', $insertCols)){
    // optional, leave user_id alone unless required by schema
}

// check for existing admin by email or full_name fallback
$found = false;
if(in_array('email', $cols)){
    $stmt = $conn->prepare("SELECT * FROM `{$table}` WHERE `email` = ? LIMIT 1");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $res = $stmt->get_result();
    if($res && $res->num_rows > 0) $found = true;
    $stmt->close();
}
if(!$found && in_array('full_name', $cols)){
    $stmt = $conn->prepare("SELECT * FROM `{$table}` WHERE `full_name` = ? LIMIT 1");
    $stmt->bind_param("s", $full_name);
    $stmt->execute();
    $res = $stmt->get_result();
    if($res && $res->num_rows > 0) $found = true;
    $stmt->close();
}

if($found){
    // update existing admin row (match by email if set, else by full_name)
    if(in_array('email', $cols)){
        $sql = "UPDATE `{$table}` SET ";
        $sets = [];
        $params = [];
        $types = '';
        foreach($insertCols as $c){
            if($c === 'email') continue; // don't change email in WHERE
            $sets[] = "`{$c}` = ?";
        }
        $sql .= implode(',', $sets) . " WHERE `email` = ?";
        $stmt = $conn->prepare($sql);
        $types = str_repeat('s', count($insertCols)-1) . 's';
        $params = array_filter($insertVals, function($k){ return true; }, ARRAY_FILTER_USE_BOTH);
        // build bind (exclude email from sets, push email at end)
        $bindParams = [];
        foreach($insertCols as $i=>$c){
            if($c === 'email') continue;
            $bindParams[] = $insertVals[$i];
        }
        $bindParams[] = $email;
        $stmt->bind_param($types, ...$bindParams);
        $stmt->execute();
        $stmt->close();
        echo "Updated existing admin by email<br>";
    } else {
        echo "Admin exists; please update password manually where appropriate.<br>";
    }
} else {
    // insert new admin
    $cols_sql = implode('`,`', $insertCols);
    $placeholders = implode(',', array_fill(0, count($insertCols), '?'));
    $sql = "INSERT INTO `{$table}` (`{$cols_sql}`) VALUES ({$placeholders})";
    $stmt = $conn->prepare($sql);
    $types = str_repeat('s', count($insertCols));
    $stmt->bind_param($types, ...$insertVals);
    if($stmt->execute()){
        echo "Inserted new admin: {$email} (password: {$password})<br>";
    } else {
        echo "Insert failed: " . $stmt->error . "<br>";
    }
    $stmt->close();
}

$conn->close();
?>