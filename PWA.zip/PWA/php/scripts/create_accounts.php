<?php
// Creates sample admin, doctor and patient accounts (run once via browser: http://localhost/PWA/php/scripts/create_accounts.php)
include_once __DIR__ . '/../config/db_connect.php';

function tableColumns($conn, $table){
    $cols = [];
    $res = $conn->query("SHOW COLUMNS FROM `{$table}`");
    if($res){
        while($r = $res->fetch_assoc()){
            $cols[] = $r['Field'];
        }
    }
    return $cols;
}

function pickColumn(array $cols, array $candidates){
    foreach($candidates as $c){
        if(in_array($c, $cols)) return $c;
    }
    return null;
}

function findIdentifierColumn($cols){
    $candidates = ['email','email_address','user_email','username','user_name','name','admin_email','doctor_email','patient_email'];
    $col = pickColumn($cols, $candidates);
    if($col) return $col;
    // fallback: first VARCHAR-like column
    foreach($cols as $c){
        return $c;
    }
    return null;
}

function insertIfNotExists($conn, $table, $email, $name, $password, $extra = []){
    $cols = tableColumns($conn, $table);
    if(empty($cols)){
        echo "Table {$table} not found or has no columns.<br>";
        return;
    }

    $idCol = findIdentifierColumn($cols);
    $passCol = pickColumn($cols, ['password','pass','pwd']);
    $nameCol = pickColumn($cols, ['name','fullname','full_name','first_name','admin_name','doctor_name']);

    if(!$idCol || !$passCol){
        echo "Table {$table} missing required identifier or password column. Found cols: " . implode(',', $cols) . "<br>";
        return;
    }

    // check existence using chosen identifier column
    $checkSql = "SELECT 1 FROM `{$table}` WHERE `{$idCol}` = ? LIMIT 1";
    $check = $conn->prepare($checkSql);
    if(!$check){
        echo "Prepare failed (check): " . $conn->error . "<br>";
        return;
    }
    $check->bind_param("s", $email);
    $check->execute();
    $res = $check->get_result();
    if($res && $res->num_rows > 0){
        echo "Account already exists in {$table} for {$email} (checked by {$idCol})<br>";
        $check->close();
        return;
    }
    $check->close();

    // build insert columns & data array
    $use = [];
    $data = [];

    // add name column if present
    if($nameCol){
        $use[] = $nameCol;
        $data[] = $name;
    }
    // add identifier column
    $use[] = $idCol;
    $data[] = $email;
    // add password (hashed)
    $use[] = $passCol;
    $data[] = password_hash($password, PASSWORD_DEFAULT);

    // include any extras if those columns exist
    foreach($extra as $k => $v){
        if(in_array($k, $cols) && !in_array($k, $use)){
            $use[] = $k;
            $data[] = $v;
        }
    }

    $cols_sql = implode(',', array_map(function($c){ return "`{$c}`"; }, $use));
    $placeholders = implode(',', array_fill(0, count($use), '?'));
    $sql = "INSERT INTO `{$table}` ({$cols_sql}) VALUES ({$placeholders})";

    $stmt = $conn->prepare($sql);
    if(!$stmt){
        echo "Prepare failed (insert): " . $conn->error . "<br>";
        return;
    }

    // bind all as strings
    $types = str_repeat('s', count($data));
    $stmt->bind_param($types, ...$data);

    if($stmt->execute()){
        echo "Inserted into {$table}: {$email} (cols: " . implode(',', $use) . ")<br>";
    } else {
        echo "Failed insert into {$table}: " . $stmt->error . "<br>";
    }
    $stmt->close();
}

insertIfNotExists($conn, 'admin', 'admin@example.com', 'Administrator', 'admin123');
insertIfNotExists($conn, 'doctors', 'dr.john@example.com', 'Dr. John', 'doc123', ['phone'=>'']);
insertIfNotExists($conn, 'patients', 'patient@example.com', 'Test Patient', 'patient123', ['phone'=>'']);

$conn->close();
?>