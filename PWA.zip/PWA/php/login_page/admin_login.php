<?php
session_start();
include_once __DIR__ . '/../config/db_connect.php';

function cols($conn,$t){ $c=[]; $r=$conn->query("SHOW COLUMNS FROM `{$t}`"); if($r) while($x=$r->fetch_assoc()) $c[]=$x['Field']; return $c; }
$cols = cols($conn,'admin');

$identifierCol = in_array('email',$cols) ? 'email' : (in_array('user_id',$cols) ? 'user_id' : (in_array('full_name',$cols) ? 'full_name' : $cols[0]));
$passCol = in_array('password',$cols) ? 'password' : null;

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $identity = trim($_POST['identity'] ?? '');
    $identityValue = htmlspecialchars($identity, ENT_QUOTES);
    $password = $_POST['password'] ?? '';

    if ($identity === '' || $password === '') { $errors[] = 'All fields are required.'; }
    elseif (!$passCol) { $errors[] = 'No password column found in admin table.'; }
    else {
        $sql = "SELECT * FROM `admin` WHERE `{$identifierCol}` = ? LIMIT 1";
        $stmt = $conn->prepare($sql);
        if(!$stmt){ $errors[] = 'DB error: '.$conn->error; }
        else {
            $stmt->bind_param("s", $identity);
            $stmt->execute();
            $res = $stmt->get_result();
            if($res && $res->num_rows > 0){
                $admin = $res->fetch_assoc();
                $hash = $admin[$passCol] ?? '';
                if ($hash && (password_verify($password, $hash) || $password === $hash)) {
                    $_SESSION['admin_id'] = $admin['admin_id'] ?? ($admin['user_id'] ?? null);
                    $_SESSION['admin_name'] = $admin['full_name'] ?? ($admin[$identifierCol] ?? 'Admin');
                    header('Location: ../../views/admin/dashboard.php');
                    exit;
                } else {
                    $errors[] = 'Invalid credentials';
                }
            } else {
                $errors[] = 'Account not found';
            }
            $stmt->close();
        }
    }
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Admin Login</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="min-h-screen flex items-center justify-center bg-gradient-to-r from-blue-50 to-blue-100">
  <div class="bg-white p-8 rounded shadow w-96">
    
    <h2 class="text-2xl font-bold text-center mb-2">Admin Login</h2>
    <p class="text-center text-gray-600 mb-4">Welcome back! Please login to your account.</p>

    <?php if($errors): ?>
      <div class="mb-4 text-red-700"><ul><?php foreach($errors as $e) echo '<li>'.htmlspecialchars($e).'</li>'; ?></ul></div>
    <?php endif; ?>

    <form method="post" class="space-y-4">
      <div>
        <label class="block text-sm text-gray-700"><?php echo $identifierCol === 'email' ? 'Email Address' : 'Username / ID'; ?></label>
        <input name="identity" type="text" autocomplete="off"
       value="<?php echo $identityValue; ?>"
       class="w-full px-3 py-2 border rounded"
       placeholder="<?php echo $identifierCol === 'email' ? 'Enter your email' : 'Enter your username or id'; ?>">
      </div>
      <div>
        <label class="block text-sm text-gray-700">Password</label>
        <input name="password" type="password" required class="w-full px-3 py-2 border rounded" placeholder="Enter your password">
      </div>
      <button type="submit" class="w-full bg-blue-600 text-white py-2 rounded">Sign In</button>
    </form>
    <p class="text-center mt-4"><a href="../../index.html" class="text-blue-600">← Back to Home</a></p>
  </div>
</body>
</html>