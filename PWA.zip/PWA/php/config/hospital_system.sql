-- Create the main database
CREATE DATABASE IF NOT EXISTS hospital_system;
USE hospital_system;

-- =======================================================
-- 1. USERS TABLE (Common login for Admin, Doctor, Patient)
-- =======================================================
CREATE TABLE users (
  user_id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  email VARCHAR(100) NOT NULL,
  password VARCHAR(255) NOT NULL,
  role ENUM('admin','doctor','patient') NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =======================================================
-- 2. ADMIN TABLE (optional, if you want specific admin info)
-- =======================================================
CREATE TABLE admin (
  admin_id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  full_name VARCHAR(100),
  contact_no VARCHAR(20),
  FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- =======================================================
-- 3. DOCTORS TABLE
-- =======================================================
CREATE TABLE doctors (
  doctor_id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  doctor_name VARCHAR(100) NOT NULL,
  specialization VARCHAR(100) NOT NULL,
  clinic_address VARCHAR(255),
  contact_no VARCHAR(20),
  email VARCHAR(100),
  status ENUM('Active','Inactive') DEFAULT 'Active',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- =======================================================
-- 4. PATIENTS TABLE
-- =======================================================
CREATE TABLE patients (
  patient_id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  full_name VARCHAR(100) NOT NULL,
  birthdate DATE,
  gender ENUM('Male','Female') DEFAULT 'Male',
  address VARCHAR(255),
  contact_no VARCHAR(20),
  email VARCHAR(100),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- =======================================================
-- 5. APPOINTMENTS TABLE
-- =======================================================
CREATE TABLE appointments (
  appointment_id INT AUTO_INCREMENT PRIMARY KEY,
  patient_id INT NOT NULL,
  doctor_id INT NOT NULL,
  full_name VARCHAR(100),
  contact_no VARCHAR(20),
  email VARCHAR(100),
  address VARCHAR(255),
  appointment_date DATE,
  appointment_time TIME,
  message TEXT,
  status ENUM('Pending','Approved','Completed','Cancelled','Rejected') DEFAULT 'Pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (patient_id) REFERENCES patients(patient_id) ON DELETE CASCADE,
  FOREIGN KEY (doctor_id) REFERENCES doctors(doctor_id) ON DELETE CASCADE
);

-- =======================================================
-- 6. MEDICAL HISTORY TABLE
-- =======================================================
CREATE TABLE medical_history (
  history_id INT AUTO_INCREMENT PRIMARY KEY,
  patient_id INT NOT NULL,
  doctor_id INT NOT NULL,
  visit_date DATE,
  condition VARCHAR(255),
  diagnosis TEXT,
  medication TEXT,
  notes TEXT,
  attachment VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (patient_id) REFERENCES patients(patient_id) ON DELETE CASCADE,
  FOREIGN KEY (doctor_id) REFERENCES doctors(doctor_id) ON DELETE CASCADE
);

-- =======================================================
-- 7. SESSION LOGS TABLE (Admin 6)
-- =======================================================
CREATE TABLE session_logs (
  log_id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  role ENUM('doctor','patient') NOT NULL,
  login_time DATETIME DEFAULT CURRENT_TIMESTAMP,
  logout_time DATETIME NULL,
  duration TIME GENERATED ALWAYS AS (TIMEDIFF(logout_time, login_time)) STORED,
  FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- =======================================================
-- 8. TRANSACTIONS TABLE (Admin 1 dashboard tracking)
-- =======================================================
CREATE TABLE transactions (
  transaction_id INT AUTO_INCREMENT PRIMARY KEY,
  appointment_id INT NOT NULL,
  doctor_id INT,
  patient_id INT,
  amount DECIMAL(10,2) DEFAULT 0.00,
  payment_status ENUM('Paid','Unpaid') DEFAULT 'Unpaid',
  transaction_date DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (appointment_id) REFERENCES appointments(appointment_id) ON DELETE CASCADE,
  FOREIGN KEY (doctor_id) REFERENCES doctors(doctor_id) ON DELETE SET NULL,
  FOREIGN KEY (patient_id) REFERENCES patients(patient_id) ON DELETE SET NULL
);

-- =======================================================
-- 9. SEARCH VIEW (Admin 7)
-- =======================================================
CREATE VIEW search_records AS
SELECT 
  a.appointment_id AS record_id,
  p.full_name AS patient_name,
  d.doctor_name AS doctor_name,
  a.appointment_date,
  a.status,
  m.condition,
  m.diagnosis
FROM appointments a
LEFT JOIN patients p ON a.patient_id = p.patient_id
LEFT JOIN doctors d ON a.doctor_id = d.doctor_id
LEFT JOIN medical_history m ON m.patient_id = p.patient_id;

-- =======================================================
-- 10. SAMPLE DEFAULT ADMIN ACCOUNT
-- =======================================================
INSERT INTO users (username, email, password, role) VALUES
('admin', 'admin@hospital.com', MD5('admin123'), 'admin');

INSERT INTO admin (user_id, full_name, contact_no)
VALUES (1, 'System Administrator', '09123456789');
